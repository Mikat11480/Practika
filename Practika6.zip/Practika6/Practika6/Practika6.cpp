﻿#include <iostream>
#include <stdexcept> // Для исключений

using namespace std;

// --- ВАРИАНТ 4 ---
struct OperationsWithArrays
{
    /**
     * @brief Объединяет два массива в третий.
     * @param a Первый массив.
     * @param b Второй массив.
     * @param size Размер каждого из входных массивов.
     * @param result Результирующий массив, должен быть размером как минимум 2*size.
     */
    static void mergeArrays(const int a[], const int b[], int size, int result[])
    {
        if (size <= 0)
            throw invalid_argument("Неверный размер массива"); // Исключение для негативного теста

        for (int i = 0; i < size; i++)
            result[i] = a[i];

        for (int i = 0; i < size; i++)
            result[i + size] = b[i];
    }

    /**
     * @brief Проверяет, одинаковые ли два массива.
     * @param a Первый массив.
     * @param b Второй массив.
     * @param size Размер массивов.
     * @return true, если массивы одинаковы, иначе false.
     */
    static bool compareArrays(const int a[], const int b[], int size)
    {
        if (size <= 0)
            throw invalid_argument("Неверный размер массива"); // Исключение для негативного теста

        for (int i = 0; i < size; i++)
            if (a[i] != b[i])
                return false;

        return true;
    }

    /**
     * @brief Создает точную копию одного массива в другом.
     * @param source Исходный массив.
     * @param destination Целевой массив.
     * @param size Размер массивов.
     */
    static void copyArray(const int source[], int destination[], int size)
    {
        if (size <= 0)
            throw invalid_argument("Неверный размер массива"); // Исключение для негативного теста

        for (int i = 0; i < size; i++)
            destination[i] = source[i];
    }

    /**
     * @brief Заполняет массив нулями.
     * @param array Массив для очистки.
     * @param size Размер массива.
     */
    static void clearArray(int array[], int size)
    {
        if (size <= 0)
            throw invalid_argument("Неверный размер массива"); // Исключение для негативного теста

        for (int i = 0; i < size; i++)
            array[i] = 0;
    }
};

// Вспомогательная функция для вывода массива (не входит в структуру)
void printArray(const int array[], int size)
{
    for (int i = 0; i < size; i++)
        cout << array[i] << " ";
    cout << endl;
}