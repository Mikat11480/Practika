﻿#include "pch.h"
#include "CppUnitTest.h"
#include <stdexcept>

// Подключаем основной код
#include "H:\Практика\Practika6\Practika6\Practika6.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace OperationsWithArraysUnitTests
{
    TEST_CLASS(OperationsWithArraysTests)
    {
    public:

        // ================= mergeArrays =================

        TEST_METHOD(MergeArrays_ValidArrays_MergedCorrectly)
        {
            int a[3] = { 1,2,3 };
            int b[3] = { 4,5,6 };
            int result[6];

            OperationsWithArrays::mergeArrays(a, b, 3, result);

            Assert::AreEqual(1, result[0]);
            Assert::AreEqual(3, result[2]);
            Assert::AreEqual(4, result[3]);
            Assert::AreEqual(6, result[5]);
        }

        // ❌ Негативный тест
        TEST_METHOD(MergeArrays_InvalidSize_ThrowsException)
        {
            int a[1] = { 1 };
            int b[1] = { 2 };
            int result[2];

            Assert::ExpectException<std::invalid_argument>(
                [&]() {
                    OperationsWithArrays::mergeArrays(a, b, 0, result);
                }
            );
        }

        // ================= compareArrays =================

        TEST_METHOD(CompareArrays_EqualArrays_ReturnsTrue)
        {
            int a[3] = { 1,2,3 };
            int b[3] = { 1,2,3 };

            bool result = OperationsWithArrays::compareArrays(a, b, 3);

            Assert::IsTrue(result);
        }

        TEST_METHOD(CompareArrays_DifferentArrays_ReturnsFalse)
        {
            int a[3] = { 1,2,3 };
            int b[3] = { 3,2,1 };

            bool result = OperationsWithArrays::compareArrays(a, b, 3);

            Assert::IsFalse(result);
        }

        // ❌ Негативный тест
        TEST_METHOD(CompareArrays_InvalidSize_ThrowsException)
        {
            int a[1] = { 1 };
            int b[1] = { 1 };

            Assert::ExpectException<std::invalid_argument>(
                [&]() {
                    OperationsWithArrays::compareArrays(a, b, 0);
                }
            );
        }

        // ================= copyArray =================

        TEST_METHOD(CopyArray_ValidCopy_ArrayCopied)
        {
            int source[4] = { 5,6,7,8 };
            int destination[4] = { 0,0,0,0 };

            OperationsWithArrays::copyArray(source, destination, 4);

            for (int i = 0; i < 4; i++)
                Assert::AreEqual(source[i], destination[i]);
        }

        // ❌ Негативный тест
        TEST_METHOD(CopyArray_InvalidSize_ThrowsException)
        {
            int source[1] = { 5 };
            int destination[1];

            Assert::ExpectException<std::invalid_argument>(
                [&]() {
                    OperationsWithArrays::copyArray(source, destination, 0);
                }
            );
        }

        // ================= clearArray =================

        TEST_METHOD(ClearArray_ValidArray_ArrayCleared)
        {
            int array[4] = { 1,2,3,4 };

            OperationsWithArrays::clearArray(array, 4);

            for (int i = 0; i < 4; i++)
                Assert::AreEqual(0, array[i]);
        }

        // ❌ Негативный тест
        TEST_METHOD(ClearArray_InvalidSize_ThrowsException)
        {
            int array[1] = { 1 };

            Assert::ExpectException<std::invalid_argument>(
                [&]() {
                    OperationsWithArrays::clearArray(array, 0);
                }
            );
        }
    };
}