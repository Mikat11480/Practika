﻿#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
using namespace std;

int countWords(const string& text) {
    int count = 0;
    bool inWord = false;

    for (char c : text) {
        if (c != ' ' && c != '\n' && c != '\t') {
            if (!inWord) {
                count++;
                inWord = true;
            }
        }
        else {
            inWord = false;
        }
    }
    return count;
}


void setTextColor(const string& color) {
    if (color == "red")
        system("color 0C");
    else if (color == "blue")
        system("color 09");
    else if (color == "green")
        system("color 0A");
    else if (color == "yellow")
        system("color 0E");
    else
        system("color 07"); 
}

int main() {
    SetConsoleCP(1251);
    SetConsoleOutputCP(1251);

    string text;
    string color;

    ifstream fin("data.txt");

    if (fin.is_open()) {
        
        getline(fin, text);
        fin >> color;
        fin.close();

        setTextColor(color);

        cout << "Сохраненный текст:\n" << text << endl;
        cout << "Количество слов: " << countWords(text) << endl;

        char choice;
        cout << "\nХотите изменить данные? (y/n): ";
        cin >> choice;
        cin.ignore();

        if (choice == 'y' || choice == 'Y') {
            cout << "Введите новый текст: ";
            getline(cin, text);

            cout << "Введите цвет текста (red, blue, green, yellow): ";
            cin >> color;

            ofstream fout("data.txt");
            fout << text << endl << color;
            fout.close();

            cout << "Данные обновлены!" << endl;
        }
    }
    else {
        
        cout << "Введите текст: ";
        getline(cin, text);

        cout << "Введите цвет текста (red, blue, green, yellow): ";
        cin >> color;

        ofstream fout("data.txt");
        fout << text << endl << color;
        fout.close();

        cout << "Данные сохранены!" << endl;
    }

    return 0;
}