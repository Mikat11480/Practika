﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Gonki
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Random r = new Random();
        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Top -= 2;
            timer1.Interval = r.Next(1, 150);
            if (pictureBox1.Top < 50)
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                label4.Text = "Победила машинка номер 1!";
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            pictureBox2.Top -= 2;
            timer2.Interval = r.Next(1, 150);
            if (pictureBox2.Top < 50)
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                label4.Text = "Победила машинка номер 2!";
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            pictureBox3.Top -= 2;
            timer3.Interval = r.Next(1, 150);
            if (pictureBox3.Top < 50)
            {
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
                label4.Text = "Победила машинка номер 3!";
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            label4.Text = "Вы поставили на машинку 1";
            timer1.Start();
            timer2.Start();
            timer3.Start();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            label4.Text = "Вы поставили на машинку 2";
            timer1.Start();
            timer2.Start();
            timer3.Start();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            label4.Text = "Вы поставили на машинку 3";
            timer1.Start();
            timer2.Start();
            timer3.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
      
    }
