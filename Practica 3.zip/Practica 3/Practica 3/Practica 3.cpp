﻿#include <iostream>
#include <string>
/// <summary>
/// Определяет тип треугольника по длинам трёх его сторон.
/// Возможные варианты: равносторонний, равнобедренный, разносторонний или невозможность существования треугольника.
/// </summary>
/// <param name="a">Длина первой стороны треугольника.</param>
/// <param name="b">Длина второй стороны треугольника.</param>
/// <param name="c">Длина третьей стороны треугольника.</param>
/// <returns>Строка, описывающая тип треугольника или причину невозможности его существования.</returns>
std::string Treygolniki(double a, double b, double c) {
	if (!(a + b > c && a + c > b && b + c > a)) {
		return "Этот треугольник не существует.";
	}
	else if (a == b && b == c) {
		return "Треугольник равносторонний.";
	}
	else if (a == b || b == c || c == a) {
		return "Треугольник равнобедренный.";
	}
	else if (a != b && b != c) {
		return "Треугольник разносторонний.";
	}
	else {
		return "Не попадает не под одно условие";
	}
}
int main()
{
	setlocale(LC_ALL, "RUS");
	double a, b, c;
	std::cout << "Введите длинны сторон треугольника" << std::endl;
	std::cin >> a >> b >> c;
	std::string result = Treygolniki(a,b,c);
	std::cout << result <<std::endl;
}